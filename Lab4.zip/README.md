# Lab4 Java Project

This project includes two simple Java programs:

1. `myFourthApp` - Calculates the sum of squares between two integer limits.
2. `SimpleCalculator` - A basic calculator with a menu for 4 operations.

Submit this project by pushing to your GitHub repository as instructed.